import os
import json
import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score
)
import warnings
warnings.filterwarnings("ignore")

app = Flask(__name__)

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
DATA_PATH  = os.path.join(BASE_DIR, "customer_churn.csv")
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")
SCALER_PATH= os.path.join(BASE_DIR, "scaler.pkl")
STATS_PATH = os.path.join(BASE_DIR, "stats.json")

FEATURES = ["Age", "Total_Purchase", "Account_Manager", "Years", "Num_Sites"]
FEATURE_FR = {
    "Age": "Âge",
    "Total_Purchase": "Achat Total",
    "Account_Manager": "Account Manager",
    "Years": "Ancienneté",
    "Num_Sites": "Nbre Sites",
}


# ─── helpers ────────────────────────────────────────────────────────────────

def _age_dist(df):
    d = df.copy()
    bins   = [0, 30, 40, 50, 60, 100]
    labels = ["<30", "30-40", "40-50", "50-60", "60+"]
    d["ag"] = pd.cut(d["Age"], bins=bins, labels=labels)
    g = d.groupby("ag", observed=True)["Churn"].agg(["sum", "count"]).reset_index()
    return {
        "labels":   labels,
        "churned":  [int(x) for x in g["sum"]],
        "total":    [int(x) for x in g["count"]],
        "retained": [int(t - c) for t, c in zip(g["count"], g["sum"])],
    }


def _build_stats(df, model, y_test, y_pred, y_proba):
    imp = {
        f: round(float(v) * 100, 2)
        for f, v in zip(FEATURES, model.feature_importances_)
    }
    imp = dict(sorted(imp.items(), key=lambda x: x[1], reverse=True))

    circumference = 314  # 2π × r=50

    metrics_raw = {
        "accuracy":  round(float(accuracy_score(y_test, y_pred)) * 100, 1),
        "precision": round(float(precision_score(y_test, y_pred, zero_division=0)) * 100, 1),
        "recall":    round(float(recall_score(y_test, y_pred, zero_division=0)) * 100, 1),
        "f1":        round(float(f1_score(y_test, y_pred, zero_division=0)) * 100, 1),
        "roc_auc":   round(float(roc_auc_score(y_test, y_proba)) * 100, 1),
    }
    # Pre-calculate SVG dash-offsets so templates stay logic-free
    metrics_offset = {
        k: round(circumference * (1 - v / 100), 2)
        for k, v in metrics_raw.items()
    }

    return {
        "total_customers": int(len(df)),
        "churn_count":     int(df["Churn"].sum()),
        "retained_count":  int((df["Churn"] == 0).sum()),
        "churn_rate":      round(float(df["Churn"].mean() * 100), 1),
        "avg_age":         round(float(df["Age"].mean()), 1),
        "avg_purchase":    int(df["Total_Purchase"].mean()),
        "avg_years":       round(float(df["Years"].mean()), 1),
        "avg_sites":       round(float(df["Num_Sites"].mean()), 1),
        "metrics":         metrics_raw,
        "metrics_offset":  metrics_offset,
        "feature_importance": imp,
        "feature_names":   list(imp.keys()),
        "feature_values":  list(imp.values()),
        "feature_fr":      {k: FEATURE_FR.get(k, k) for k in imp.keys()},
        "age_dist":        _age_dist(df),
    }


# ─── training ────────────────────────────────────────────────────────────────

def train():
    df = pd.read_csv(DATA_PATH)
    X  = df[FEATURES].fillna(df[FEATURES].mean())
    y  = df["Churn"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler   = StandardScaler()
    Xs_train = scaler.fit_transform(X_train)
    Xs_test  = scaler.transform(X_test)

    clf = RandomForestClassifier(
        n_estimators=300,
        max_depth=12,
        min_samples_leaf=4,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )
    clf.fit(Xs_train, y_train)

    y_pred  = clf.predict(Xs_test)
    y_proba = clf.predict_proba(Xs_test)[:, 1]

    stats = _build_stats(df, clf, y_test, y_pred, y_proba)

    joblib.dump(clf,    MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    with open(STATS_PATH, "w") as fh:
        json.dump(stats, fh, indent=2)

    return clf, scaler, stats


def load_or_train():
    if all(os.path.exists(p) for p in [MODEL_PATH, SCALER_PATH, STATS_PATH]):
        clf    = joblib.load(MODEL_PATH)
        scaler = joblib.load(SCALER_PATH)
        with open(STATS_PATH) as fh:
            stats = json.load(fh)
        return clf, scaler, stats
    return train()


model, scaler, stats = load_or_train()


# ─── routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", stats=stats)


@app.route("/predict")
def predict_page():
    return render_template("predict.html", stats=stats)


@app.route("/api/predict", methods=["POST"])
def api_predict():
    data = request.get_json(force=True)
    try:
        X = np.array([[
            float(data["age"]),
            float(data["total_purchase"]),
            int(data["account_manager"]),
            float(data["years"]),
            float(data["num_sites"]),
        ]])
        Xs   = scaler.transform(X)
        pred = int(model.predict(Xs)[0])
        prob = model.predict_proba(Xs)[0]

        p_churn = round(float(prob[1]) * 100, 1)

        if p_churn >= 65:
            risk, risk_cls = "Élevé",  "danger"
        elif p_churn >= 35:
            risk, risk_cls = "Modéré", "warning"
        else:
            risk, risk_cls = "Faible", "success"

        return jsonify({
            "success":    True,
            "churn":      pred,
            "prob_churn": p_churn,
            "prob_retain": round(float(prob[0]) * 100, 1),
            "risk":       risk,
            "risk_class": risk_cls,
        })
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 400


@app.route("/api/retrain", methods=["POST"])
def api_retrain():
    global model, scaler, stats
    try:
        model, scaler, stats = train()
        return jsonify({"success": True, "metrics": stats["metrics"]})
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
